/**
 * supabase-config.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Fill in SUPABASE_URL and SUPABASE_ANON_KEY from your Supabase project.
 *
 * Setup (free, no credit card):
 *   1. Go to https://supabase.com and sign up
 *   2. Click "New project" — fill in name and a database password, click Create
 *   3. Wait ~1 minute for it to spin up
 *   4. Go to Project Settings → API
 *   5. Copy "Project URL" → paste as SUPABASE_URL below
 *   6. Copy "anon public" key → paste as SUPABASE_ANON_KEY below
 *
 * Then run this SQL in Supabase → SQL Editor → New query:
 * ─────────────────────────────────────────────────────────────────────────────
 *   create table messages (
 *     id          bigint generated always as identity primary key,
 *     server_id   text        not null,
 *     user_id     bigint      not null,
 *     username    text        not null,
 *     text        text        not null,
 *     created_at  timestamptz not null default now()
 *   );
 *
 *   -- Index so queries by server_id are fast
 *   create index on messages (server_id, created_at desc);
 *
 *   -- Allow anyone with the anon key to read and insert (no auth needed)
 *   alter table messages enable row level security;
 *   create policy "read"   on messages for select using (true);
 *   create policy "insert" on messages for insert with check (true);
 *
 *   -- Auto-delete messages older than 24 hours (keeps DB clean)
 *   create or replace function delete_old_messages() returns trigger as $$
 *   begin
 *     delete from messages where created_at < now() - interval '24 hours';
 *     return new;
 *   end;
 *   $$ language plpgsql;
 *
 *   create trigger cleanup_old_messages
 *     after insert on messages
 *     for each statement execute function delete_old_messages();
 * ─────────────────────────────────────────────────────────────────────────────
 */

const SUPABASE_URL      = "https://qfquqnwnnaacxeihxnus.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_dVUXibT8T0pxEftEK4dkNA_ruJkKRPf";
