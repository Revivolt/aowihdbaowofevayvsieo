/**
 * chat.js — popup window for Roblox Server Chat
 * Reads from chrome.storage.local (written by content.js).
 * Writes rsc_outgoing to trigger message sends.
 */

const statusDot   = document.getElementById('status-dot');
const serverLabel = document.getElementById('server-label');
const playerCount = document.getElementById('player-count');
const messagesEl  = document.getElementById('messages');
const waitSplash  = document.getElementById('waiting-splash');
const msgInput    = document.getElementById('msg-input');
const sendBtn     = document.getElementById('send-btn');

let lastMsgCount = 0;
let connected    = false;
let heartbeatTimer = null;

// Check if content script is still alive via heartbeat.
// If stale (> 15 s), disable input and show a banner.
function checkHeartbeat() {
  chrome.storage.local.get('rsc_heartbeat', ({ rsc_heartbeat: hb }) => {
    const stale = !hb || (Date.now() - hb) > 15_000;
    const banner = document.getElementById('disconnected-banner');
    if (stale) {
      if (!banner) {
        const el = document.createElement('div');
        el.id            = 'disconnected-banner';
        el.textContent   = '⚠️ Return to the Roblox game page to reconnect.';
        document.getElementById('header').after(el);
      }
      msgInput.disabled = true;
      sendBtn.disabled  = true;
    } else {
      banner?.remove();
      // Re-enable only if we're actually connected
      if (connected) {
        msgInput.disabled = false;
        sendBtn.disabled  = false;
      }
    }
  });
}
heartbeatTimer = setInterval(checkHeartbeat, 5000);

/* ─── Server info ────────────────────────────────────────────────────────── */

function setStatus(state) {
  const map = {
    connected:    { dot: '●', color: '#4ade80', title: 'Connected' },
    resolving:    { dot: '●', color: '#facc15', title: 'Resolving players…' },
    disconnected: { dot: '●', color: '#64748b', title: 'Waiting for game…' },
  };
  const s = map[state] ?? map.disconnected;
  statusDot.textContent = s.dot;
  statusDot.style.color = s.color;
  statusDot.title       = s.title;
}

function renderServerInfo(info) {
  if (!info?.serverId) {
    serverLabel.textContent   = 'Waiting for server…';
    playerCount.textContent   = '';
    setStatus('disconnected');
    connected                 = false;
    msgInput.disabled         = true;
    sendBtn.disabled          = true;
    waitSplash.style.display  = 'flex';
    messagesEl.style.display  = 'none';
    return;
  }
  waitSplash.style.display  = 'none';
  messagesEl.style.display  = 'flex';
  serverLabel.textContent   = `Server: ${info.serverId.slice(0, 8)}…`;
  serverLabel.title         = info.serverId;
  if (info.playerCount != null)
    playerCount.textContent = `${info.playerCount} player${info.playerCount === 1 ? '' : 's'}`;
  const isConnected = info.status === 'connected';
  setStatus(isConnected ? 'connected' : 'resolving');
  connected         = isConnected;
  msgInput.disabled = !isConnected;
  sendBtn.disabled  = !isConnected;
  if (isConnected) msgInput.focus();
}

/* ─── Messages ───────────────────────────────────────────────────────────── */

function renderMessages(msgs) {
  if (!msgs?.length || msgs.length === lastMsgCount) return;
  const newMsgs  = msgs.slice(lastMsgCount);
  lastMsgCount   = msgs.length;
  const atBottom = messagesEl.scrollHeight - messagesEl.scrollTop
    <= messagesEl.clientHeight + 40;

  for (const msg of newMsgs) {
    if (msg.system) {
      const el = document.createElement('div');
      el.className   = 'sys-msg';
      el.textContent = msg.text;
      messagesEl.appendChild(el);
      continue;
    }
    const wrap   = document.createElement('div');
    wrap.className = `msg ${msg.self ? 'msg-self' : 'msg-other'}`;
    const name   = document.createElement('span');
    name.className   = 'msg-name';
    name.textContent = msg.username ?? '';
    const bubble = document.createElement('span');
    bubble.className   = 'msg-bubble';
    bubble.textContent = msg.text;
    const time   = document.createElement('span');
    time.className   = 'msg-time';
    time.textContent = new Date(msg.timestamp).toLocaleTimeString([], {
      hour: '2-digit', minute: '2-digit',
    });
    wrap.appendChild(name);
    wrap.appendChild(bubble);
    wrap.appendChild(time);
    messagesEl.appendChild(wrap);
  }
  if (atBottom) messagesEl.scrollTop = messagesEl.scrollHeight;
}

function showError(errText) {
  if (!errText) return;
  const el = document.createElement('div');
  el.className   = 'sys-msg error-msg';
  el.textContent = `⚠️ ${errText}`;
  messagesEl.appendChild(el);
  messagesEl.scrollTop  = messagesEl.scrollHeight;
  msgInput.disabled     = !connected;
  sendBtn.disabled      = !connected;
}

/* ─── Initial load ───────────────────────────────────────────────────────── */

chrome.storage.local.get(['rsc_server', 'rsc_messages', 'rsc_error'], (data) => {
  renderServerInfo(data.rsc_server ?? null);
  if (data.rsc_messages?.length) { lastMsgCount = 0; renderMessages(data.rsc_messages); }
  if (data.rsc_error) showError(data.rsc_error);
});

/* ─── Live updates ───────────────────────────────────────────────────────── */

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.rsc_server)   renderServerInfo(changes.rsc_server.newValue ?? null);
  if (changes.rsc_messages) renderMessages(changes.rsc_messages.newValue ?? []);
  if (changes.rsc_error?.newValue) showError(changes.rsc_error.newValue);
});

/* ─── Send ───────────────────────────────────────────────────────────────── */

function sendMessage() {
  const text = msgInput.value.trim();
  if (!text || !connected) return;
  msgInput.value    = '';
  msgInput.disabled = true;
  sendBtn.disabled  = true;
  chrome.storage.local.set({ rsc_outgoing: { text, nonce: Date.now() } }, () => {
    // Always re-enable — never make re-enabling conditional on `connected`
    // because connected may briefly flip to false during writeServerInfo calls
    setTimeout(() => {
      msgInput.disabled = false;
      sendBtn.disabled  = false;
      msgInput.focus();
    }, 1800);
  });
}

sendBtn.addEventListener('click', sendMessage);
msgInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  if (e.key === 'Escape') e.preventDefault();
});
window.addEventListener('focus', () => { if (!msgInput.disabled) msgInput.focus(); });
