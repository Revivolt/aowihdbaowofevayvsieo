# Roblox Server Chat — Supabase Edition

Real-time chat for everyone using the extension on the same Roblox server.
Uses Supabase as a free shared database — no server to run, no credit card needed.

---

## One-time setup (5 minutes)

### 1. Create a free Supabase project

1. Go to https://supabase.com and sign up (free, no credit card)
2. Click **New project**, give it a name, set a database password, click Create
3. Wait about 1 minute for it to spin up

### 2. Create the messages table

In your Supabase project, go to **SQL Editor → New query**, paste this, and click Run:

```sql
create table messages (
  id          bigint generated always as identity primary key,
  server_id   text        not null,
  user_id     bigint      not null,
  username    text        not null,
  text        text        not null,
  created_at  timestamptz not null default now()
);

create index on messages (server_id, created_at desc);

alter table messages enable row level security;
create policy "read"   on messages for select using (true);
create policy "insert" on messages for insert with check (true);

create or replace function delete_old_messages() returns trigger as $$
begin
  delete from messages where created_at < now() - interval '24 hours';
  return new;
end;
$$ language plpgsql;

create trigger cleanup_old_messages
  after insert on messages
  for each statement execute function delete_old_messages();
```

### 3. Fill in supabase-config.js

In your Supabase project go to **Project Settings → API** and copy:
- **Project URL** → paste as `SUPABASE_URL`
- **anon public** key → paste as `SUPABASE_ANON_KEY`

```js
const SUPABASE_URL      = "https://xxxx.supabase.co";
const SUPABASE_ANON_KEY = "eyJ...";
```

### 4. Load the extension

1. Go to `chrome://extensions`
2. Enable **Developer mode**
3. Click **Load unpacked** → select this folder
4. Done — share the folder (or a zip of it) with friends

---

## How it works

- Messages are stored in your Supabase database, scoped by server ID
- Everyone with the extension polls for new messages every 3 seconds
- Messages older than 24 hours are automatically deleted
- The extension detects which server you're in via Roblox's Presence API

---

## Files

```
roblox-supabase-chat/
├── manifest.json       Extension config
├── supabase-config.js  ← Fill this in
├── content.js          Presence detection + Supabase messaging
├── interceptor.js      Captures Roblox server ID at join time
├── background.js       Opens the chat window
├── chat.html           Chat popup window
├── chat.js             Chat popup UI
└── chat.css            Chat popup styles
```
