/**
 * content.js — Roblox Server Chat (Supabase edition)
 *
 * Responsibilities:
 *   1. Detect which Roblox server the user is in (presence API polling)
 *   2. Send messages → INSERT into Supabase messages table
 *   3. Receive messages → long-poll Supabase for new rows
 *   4. Relay everything to the chat window via chrome.storage.local
 *
 * chrome.storage.local keys:
 *   rsc_server     { serverId, placeId, username, userId, status }
 *   rsc_messages   [ { id, username, text, timestamp, self } ]  max 80
 *   rsc_outgoing   { text, nonce }   written by chat.js to trigger a send
 *   rsc_error      string
 *   rsc_heartbeat  number (timestamp — chat.js uses this to detect dead tab)
 */

/* ─── 0. Config sanity check ────────────────────────────────────────────── */
if (!SUPABASE_URL || SUPABASE_URL.includes('YOUR_PROJECT_URL')) {
  console.error('[RSC] supabase-config.js is not configured. Extension will not work.');
}

/* ─── 1. Page-world interceptor ─────────────────────────────────────────── */
(function () {
  const s = document.createElement('script');
  s.src = chrome.runtime.getURL('interceptor.js');
  s.onload = () => s.remove();
  (document.head || document.documentElement).appendChild(s);
})();

/* ─── 2. State ──────────────────────────────────────────────────────────── */
let serverId      = null;
let placeId       = null;
let myUserId      = null;
let myUsername    = null;
let presenceTimer = null;
let pollTimer     = null;
let lastOutgoing  = null;
let lastMessageId = 0;    // highest message ID we've seen — used for incremental fetches

const log  = (...a) => console.log('[RSC]',  ...a);
const warn = (...a) => console.warn('[RSC]', ...a);

/* ─── 3. Storage helpers ─────────────────────────────────────────────────── */

function storageGet(keys) {
  return new Promise((res, rej) => {
    chrome.storage.local.get(keys, r => {
      chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res(r);
    });
  });
}

function storageSet(obj) {
  return new Promise((res, rej) => {
    chrome.storage.local.set(obj, () => {
      chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res();
    });
  });
}

async function appendMessages(newMsgs) {
  if (!newMsgs.length) return;
  const { rsc_messages: prev = [] } = await storageGet('rsc_messages');
  await storageSet({ rsc_messages: [...prev, ...newMsgs].slice(-80) });
}

/* ─── 4. Supabase REST helpers ──────────────────────────────────────────── */

const SB_HEADERS = {
  'apikey':        SUPABASE_ANON_KEY,
  'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
  'Content-Type':  'application/json',
};

// Insert a message row
async function sbInsert(row) {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/messages`, {
    method:  'POST',
    headers: { ...SB_HEADERS, 'Prefer': 'return=representation' },
    body:    JSON.stringify(row),
  });
  if (!r.ok) {
    const err = await r.text().catch(() => r.status);
    throw new Error(`Supabase insert failed: ${err}`);
  }
  return r.json();
}

// Fetch messages newer than lastMessageId for this server
async function sbFetch(sid, afterId) {
  const url = `${SUPABASE_URL}/rest/v1/messages`
    + `?server_id=eq.${encodeURIComponent(sid)}`
    + `&id=gt.${afterId}`
    + `&order=id.asc`
    + `&limit=50`;
  const r = await fetch(url, { headers: SB_HEADERS });
  if (!r.ok) throw new Error(`Supabase fetch failed: ${r.status}`);
  return r.json(); // array of rows
}

/* ─── 5. Roblox API helpers ─────────────────────────────────────────────── */

async function getMyUser() {
  const r = await fetch('https://users.roblox.com/v1/users/authenticated',
    { credentials: 'include' });
  if (!r.ok) throw new Error(`Not authenticated (${r.status})`);
  return r.json();
}

async function getMyPresence() {
  if (!myUserId) return null;
  const r = await fetch('https://presence.roblox.com/v1/presence/users', {
    method:      'POST',
    credentials: 'include',
    headers:     { 'Content-Type': 'application/json' },
    body:        JSON.stringify({ userIds: [myUserId] }),
  });
  if (!r.ok) { warn('Presence HTTP', r.status); return null; }
  const d = await r.json();
  const p = d.userPresences?.[0];
  log('Presence →', JSON.stringify(p));
  if (!p || p.userPresenceType !== 2) return null;

  const sid = (p.gameId && p.gameId !== '00000000-0000-0000-0000-000000000000')
    ? p.gameId
    : (p.universeId ? `u${p.universeId}` : null);

  return sid ? { serverId: sid, universeId: p.universeId, placeId: p.placeId } : null;
}

async function getUniverseId(pid) {
  const r = await fetch(
    `https://games.roblox.com/v1/games/multiget-place-details?placeIds=${pid}`,
    { credentials: 'include' });
  if (!r.ok) return null;
  const d = await r.json();
  return d[0]?.universeId ?? null;
}

/* ─── 6. Message polling ────────────────────────────────────────────────── */

async function pollMessages() {
  if (!serverId) return;
  try {
    const rows = await sbFetch(serverId, lastMessageId);
    if (!rows.length) return;

    const msgs = rows.map(row => ({
      id:        row.id,
      username:  row.username,
      text:      row.text,
      timestamp: new Date(row.created_at).getTime(),
      self:      row.user_id === myUserId,
    }));

    lastMessageId = rows[rows.length - 1].id;
    await appendMessages(msgs);
  } catch (e) {
    warn('Poll error:', e.message);
  }
}

/* ─── 7. Outgoing message handler ───────────────────────────────────────── */

chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area !== 'local' || !changes.rsc_outgoing) return;
  const { newValue } = changes.rsc_outgoing;
  if (!newValue || newValue.nonce === lastOutgoing) return;
  lastOutgoing = newValue.nonce;

  if (!serverId || !myUserId) {
    await storageSet({ rsc_error: 'Not connected to a server yet.' }).catch(() => {});
    return;
  }

  const text = newValue.text?.trim();
  if (!text) return;

  try {
    await sbInsert({
      server_id: serverId,
      user_id:   myUserId,
      username:  myUsername,
      text,
    });
    // Don't echo locally — pollMessages will pick it up and self:true will style it
  } catch (e) {
    warn('Send error:', e.message);
    await storageSet({ rsc_error: `Send failed: ${e.message}` }).catch(() => {});
  }
});

/* ─── 8. Server join ────────────────────────────────────────────────────── */

async function onServerJoined(presence) {
  try {
    const newId = (typeof presence === 'string') ? presence : presence?.serverId;
    if (!newId || newId === serverId) return;

    const isSwitch = serverId !== null;
    serverId      = newId;
    lastMessageId = 0;
    log('--- SERVER JOINED ---', serverId);

    clearInterval(pollTimer);
    pollTimer = null;

    placeId = (typeof presence === 'object' && presence.placeId)
      ? String(presence.placeId) : extractPlaceId();

    // Resolve universeId if placeId is available but universeId is not
    let uid = (typeof presence === 'object') ? presence.universeId : null;
    if (!uid && placeId) uid = await getUniverseId(placeId).catch(() => null);

    await storageSet({
      rsc_messages: isSwitch ? [] : (await storageGet('rsc_messages').then(d => d.rsc_messages ?? [])),
      rsc_error:    null,
      rsc_server: {
        serverId,
        placeId,
        username: myUsername,
        userId:   myUserId,
        status:   'connected',
      },
    });

    // Open the chat window
    chrome.runtime.sendMessage({ type: 'OPEN_WINDOW' }, (resp) => {
      if (chrome.runtime.lastError) warn('sendMessage error:', chrome.runtime.lastError.message);
      else log('Window opened:', JSON.stringify(resp));
    });

    // Load recent history (last 50 messages for this server)
    try {
      const history = await sbFetch(serverId, 0);
      if (history.length) {
        lastMessageId = history[history.length - 1].id;
        const msgs = history.map(row => ({
          id:        row.id,
          username:  row.username,
          text:      row.text,
          timestamp: new Date(row.created_at).getTime(),
          self:      row.user_id === myUserId,
        }));
        await appendMessages(msgs);
      }
    } catch (e) {
      warn('History fetch failed:', e.message);
    }

    await appendMessages([{
      system:    true,
      text:      `Connected to server ${serverId.slice(0, 8)}…`,
      timestamp: Date.now(),
    }]);

    // Poll for new messages every 3 seconds
    pollTimer = setInterval(pollMessages, 3000);
    log('Ready — polling for messages.');

  } catch (err) {
    warn('onServerJoined FAILED:', err.message, err.stack);
    await storageSet({ rsc_error: `Connection error: ${err.message}` }).catch(() => {});
  }
}

/* ─── 9. Presence polling ───────────────────────────────────────────────── */

async function presenceTick() {
  try {
    if (!myUserId) {
      const user = await getMyUser();
      myUserId   = user.id;
      myUsername = user.name;
      log('Logged in as', myUsername, '(id:', myUserId + ')');
    }

    const presence = await getMyPresence().catch(e => { warn('Presence error:', e.message); return null; });
    if (presence && presence.serverId !== serverId) {
      log('New server detected:', presence.serverId);
      await onServerJoined(presence);
    }
  } catch (e) {
    warn('presenceTick error:', e.message);
  }
}

/* ─── 10. Utils ─────────────────────────────────────────────────────────── */

function extractPlaceId() {
  const m = window.location.pathname.match(/\/games\/(\d+)/);
  return m ? m[1] : null;
}

/* ─── 11. Bootstrap ─────────────────────────────────────────────────────── */

log('Content script loaded on', window.location.href);

// Fast-path: interceptor
window.addEventListener('message', e => {
  if (e.source !== window) return;
  if (e.data?.__rsc && e.data.type === 'RSC_JOB_ID' && e.data.jobId) {
    log('Job ID from interceptor:', e.data.jobId);
    onServerJoined(e.data.jobId);
  }
});

// Fast-path: URL param
const qid = new URLSearchParams(window.location.search).get('gameInstanceId');
if (qid) { log('Job ID from URL:', qid); onServerJoined(qid); }

// Primary: presence polling
presenceTick();
presenceTimer = setInterval(presenceTick, 5000);

// Heartbeat for chat window to detect dead tabs
function writeHeartbeat() {
  storageSet({ rsc_heartbeat: Date.now() }).catch(() => {});
}
writeHeartbeat();
setInterval(writeHeartbeat, 10_000);

window.addEventListener('beforeunload', () => {
  clearInterval(presenceTimer);
  clearInterval(pollTimer);
});
