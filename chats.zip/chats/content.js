/**
 * content.js — Roblox Server Chat
 *
 * Uses chrome.storage.local (not session) — universally available in all
 * extension contexts including content scripts.
 *
 * Uses chrome.runtime.sendMessage to wake background.js for window management.
 * sendMessage from a content script is guaranteed to wake the service worker.
 *
 * Storage keys (chrome.storage.local):
 *   rsc_server    { serverId, placeId, username, userId, playerCount, status }
 *   rsc_messages  [ { username, text, timestamp, self, system } ]  max 80
 *   rsc_outgoing  { text, nonce }   written by chat.js
 *   rsc_error     string
 */

/* ─── 0. Page-world interceptor ─────────────────────────────────────────── */
(function () {
  const s = document.createElement('script');
  s.src = chrome.runtime.getURL('interceptor.js');
  s.onload = () => s.remove();
  (document.head || document.documentElement).appendChild(s);
})();

/* ─── 1. State ──────────────────────────────────────────────────────────── */
let serverId      = null;
let placeId       = null;
let myUserId      = null;
let myUsername    = null;
let originalBio   = null;
let csrfToken     = null;
let bioPollTimer  = null;
let presenceTimer = null;
let lastOutgoing  = null;
const seenMsgs    = new Map();
let playerList    = [];

const log  = (...a) => console.log('[RSC]',  ...a);
const warn = (...a) => console.warn('[RSC]', ...a);

/* ─── 2. Storage helpers (chrome.storage.local) ─────────────────────────── */

function storageGet(keys) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(keys, (result) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(result);
    });
  });
}

function storageSet(obj) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(obj, () => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve();
    });
  });
}

async function writeServerInfo(extra = {}) {
  await storageSet({
    rsc_server: {
      serverId,
      placeId,
      username:    myUsername,
      userId:      myUserId,
      playerCount: 0,
      status:      'connected',
      ...extra,
    },
  });
}

async function appendMessage(msg) {
  const data = await storageGet('rsc_messages');
  const prev = data.rsc_messages ?? [];
  await storageSet({ rsc_messages: [...prev, msg].slice(-80) });
}

/* ─── 3. Roblox API helpers ─────────────────────────────────────────────── */

async function getMyUser() {
  const r = await fetch('https://users.roblox.com/v1/users/authenticated',
    { credentials: 'include' });
  if (!r.ok) throw new Error(`Not authenticated (${r.status})`);
  return r.json();
}

async function getMyPresence() {
  if (!myUserId) return null;
  const r = await fetch('https://presence.roblox.com/v1/presence/users', {
    method:      'POST',
    credentials: 'include',
    headers:     { 'Content-Type': 'application/json' },
    body:        JSON.stringify({ userIds: [myUserId] }),
  });
  if (!r.ok) { warn('Presence HTTP', r.status); return null; }
  const d = await r.json();
  const p = d.userPresences?.[0];
  log('Presence →', JSON.stringify(p));
  if (!p || p.userPresenceType !== 2) return null;

  const sid = (p.gameId && p.gameId !== '00000000-0000-0000-0000-000000000000')
    ? p.gameId
    : (p.universeId ? `u${p.universeId}` : null);

  return sid ? { serverId: sid, universeId: p.universeId, placeId: p.placeId } : null;
}

async function getUserDescription(userId) {
  const r = await fetch(`https://users.roblox.com/v1/users/${userId}`,
    { credentials: 'include' });
  if (!r.ok) return '';
  return (await r.json()).description ?? '';
}

async function getCsrf() {
  if (csrfToken) return csrfToken;
  const r = await fetch('https://auth.roblox.com/v2/logout',
    { method: 'POST', credentials: 'include' });
  csrfToken = r.headers.get('x-csrf-token') || '';
  return csrfToken;
}

async function setMyBio(text) {
  const post = (token) => fetch(
    'https://accountinformation.roblox.com/v1/description', {
      method:      'POST',
      credentials: 'include',
      headers:     { 'Content-Type': 'application/json', 'X-CSRF-Token': token },
      body:        JSON.stringify({ description: text }),
    });
  let r = await post(await getCsrf());
  if (r.status === 403) {
    csrfToken = r.headers.get('x-csrf-token') || null;
    if (!csrfToken) return false;
    r = await post(csrfToken);
  }
  return r.ok;
}

async function getUniverseId(pid) {
  const r = await fetch(
    `https://games.roblox.com/v1/games/multiget-place-details?placeIds=${pid}`,
    { credentials: 'include' });
  if (!r.ok) return null;
  const d = await r.json();
  return d[0]?.universeId ?? null;
}

async function getServerPlayers(universeId, jobId) {
  if (!jobId || jobId.startsWith('u')) return [];
  let cursor = null;
  for (let page = 0; page < 20; page++) {
    const url = `https://games.roblox.com/v1/games/${universeId}/servers/Public?limit=100`
      + (cursor ? `&cursor=${encodeURIComponent(cursor)}` : '');
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) break;
    const d   = await r.json();
    const srv = d.data?.find(s => s.id === jobId);
    if (srv) return srv.players ?? [];
    cursor = d.nextPageCursor;
    if (!cursor) break;
  }
  return [];
}

async function resolvePlayerIds(players) {
  const unresolved = players.filter(p => !p.id || p.id === 0);
  if (unresolved.length) {
    const r = await fetch('https://users.roblox.com/v1/usernames/users', {
      method:      'POST',
      credentials: 'include',
      headers:     { 'Content-Type': 'application/json' },
      body:        JSON.stringify({
        usernames: unresolved.map(p => p.userName),
        excludeBannedUsers: false,
      }),
    }).catch(() => null);
    if (r?.ok) {
      const d   = await r.json();
      const map = Object.fromEntries((d.data ?? []).map(u => [u.name, u.id]));
      players   = players.map(p =>
        (!p.id || p.id === 0) ? { ...p, id: map[p.userName] ?? 0 } : p);
    }
  }
  return players.map(p => ({ id: p.id, username: p.userName || p.displayName || 'Unknown' }));
}

/* ─── 4. Bio format ─────────────────────────────────────────────────────── */

function encodeBio(text) {
  return JSON.stringify({ rsc: 1, s: serverId.slice(0, 12), t: Date.now(), m: text });
}

function decodeBio(bio) {
  if (!bio) return null;
  try {
    const o = JSON.parse(bio.trim());
    if (o.rsc === 1 && typeof o.s === 'string'
      && typeof o.t === 'number' && typeof o.m === 'string') return o;
  } catch { /**/ }
  return null;
}

/* ─── 5. Bio polling ─────────────────────────────────────────────────────── */

async function pollBios() {
  if (!serverId || !playerList.length) return;
  for (const player of playerList) {
    if (!player.id || player.id === myUserId) continue;
    try {
      const bio = await getUserDescription(player.id);
      const msg = decodeBio(bio);
      if (!msg) continue;
      if (!serverId.startsWith(msg.s) && !msg.s.startsWith(serverId.slice(0, 12))) continue;
      const last = seenMsgs.get(player.id) ?? 0;
      if (msg.t > last) {
        seenMsgs.set(player.id, msg.t);
        await appendMessage({ username: player.username, text: msg.m, timestamp: msg.t });
      }
    } catch { /**/ }
  }
}

/* ─── 6. Outgoing message handler ───────────────────────────────────────── */

chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area !== 'local' || !changes.rsc_outgoing) return;
  const { newValue } = changes.rsc_outgoing;
  if (!newValue || newValue.nonce === lastOutgoing) return;
  lastOutgoing = newValue.nonce;

  if (!serverId || !myUserId) {
    await storageSet({ rsc_error: 'Not in a server yet.' }).catch(() => {});
    return;
  }
  const text = newValue.text?.trim();
  if (!text) return;

  const ok = await setMyBio(encodeBio(text)).catch(e => { warn('Bio error:', e); return false; });
  if (!ok) {
    await storageSet({ rsc_error: 'Bio update failed — are you logged in to Roblox?' }).catch(() => {});
    return;
  }
  await appendMessage({ username: myUsername, text, timestamp: Date.now(), self: true });
  setTimeout(() => {
    if (originalBio !== null) setMyBio(originalBio).catch(() => {});
  }, 45_000);
});

/* ─── 7. Server join ────────────────────────────────────────────────────── */

async function onServerJoined(presence) {
  try {
    const newId = (typeof presence === 'string') ? presence : presence?.serverId;
    if (!newId || newId === serverId) return;
    serverId = newId;
    log('--- SERVER JOINED ---', serverId);

    clearInterval(bioPollTimer);
    bioPollTimer = null;
    seenMsgs.clear();
    playerList = [];

    // Save original bio once
    if (myUserId && originalBio === null) {
      originalBio = await getUserDescription(myUserId).catch(() => '');
      log('Saved original bio:', JSON.stringify(originalBio));
    }

    // Clear old messages
    log('Writing to storage.local...');
    await storageSet({ rsc_messages: [], rsc_error: null });
    await writeServerInfo({ status: 'resolving' });
    log('Storage write OK');

    // Ask background.js to open the window via sendMessage.
    // This is the ONLY reliable way to wake a sleeping MV3 service worker
    // from a content script. Storage changes do NOT wake service workers.
    log('Sending OPEN_WINDOW to background...');
    chrome.runtime.sendMessage({ type: 'OPEN_WINDOW' }, (resp) => {
      if (chrome.runtime.lastError) {
        warn('sendMessage error:', chrome.runtime.lastError.message);
      } else {
        log('background.js opened window:', JSON.stringify(resp));
      }
    });

    // Resolve players
    let uid  = (typeof presence === 'object') ? presence.universeId : null;
    placeId  = (typeof presence === 'object' && presence.placeId)
      ? String(presence.placeId) : extractPlaceId();

    if (!uid && placeId) uid = await getUniverseId(placeId).catch(() => null);
    log('universeId:', uid, '| placeId:', placeId);

    if (uid && !serverId.startsWith('u')) {
      const raw = await getServerPlayers(uid, serverId).catch(() => []);
      playerList = await resolvePlayerIds(raw).catch(() => []);
    }
    log('Players resolved:', playerList.length);

    await writeServerInfo({ status: 'connected', playerCount: playerList.length });
    await appendMessage({
      system: true,
      text: `Connected — ${playerList.length} player(s) on this server.`,
      timestamp: Date.now(),
    });

    bioPollTimer = setInterval(pollBios, 4000);
    log('Ready. Bio polling started.');

  } catch (err) {
    // Surface the real error so we can see it in console
    warn('onServerJoined FAILED:', err.message, err.stack);
    await storageSet({ rsc_error: `Connection error: ${err.message}` }).catch(() => {});
  }
}

/* ─── 8. Presence polling ───────────────────────────────────────────────── */

async function presenceTick() {
  try {
    if (!myUserId) {
      const user = await getMyUser();
      myUserId   = user.id;
      myUsername = user.name;
      log('Logged in as', myUsername, '(id:', myUserId + ')');
    }

    const presence = await getMyPresence().catch(e => {
      warn('Presence error:', e.message); return null;
    });
    if (presence && presence.serverId !== serverId) {
      log('New server detected:', presence.serverId);
      await onServerJoined(presence);
    }
  } catch (e) {
    // Don't let errors stop the interval — just log and retry next tick
    warn('presenceTick error:', e.message);
  }
}

/* ─── 9. Utils ──────────────────────────────────────────────────────────── */

function extractPlaceId() {
  const m = window.location.pathname.match(/\/games\/(\d+)/);
  return m ? m[1] : null;
}

/* ─── 10. Bootstrap ─────────────────────────────────────────────────────── */

log('Content script loaded on', window.location.href);

// Clear stale data from a previous session
storageSet({ rsc_server: null, rsc_messages: [], rsc_error: null })
  .catch(e => warn('Initial storage clear failed:', e.message));

// Fast-path: interceptor
window.addEventListener('message', e => {
  if (e.source !== window) return;
  if (e.data?.__rsc && e.data.type === 'RSC_JOB_ID' && e.data.jobId) {
    log('Job ID from interceptor:', e.data.jobId);
    onServerJoined(e.data.jobId);
  }
});

// Fast-path: URL param
const qid = new URLSearchParams(window.location.search).get('gameInstanceId');
if (qid) { log('Job ID from URL:', qid); onServerJoined(qid); }

// Primary: presence polling
log('Starting presence polling...');
presenceTick();
presenceTimer = setInterval(presenceTick, 5000);

window.addEventListener('beforeunload', () => {
  clearInterval(presenceTimer);
  clearInterval(bioPollTimer);
  if (originalBio !== null) {
    navigator.sendBeacon(
      'https://accountinformation.roblox.com/v1/description',
      new Blob([JSON.stringify({ description: originalBio })], { type: 'application/json' })
    );
  }
});
