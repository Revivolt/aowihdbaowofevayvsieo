/**
 * interceptor.js — runs in the PAGE's main world (not content-script sandbox)
 * so it can monkey-patch fetch/XHR before Roblox's own code runs.
 * It posts RSC_JOB_ID messages back to the content script via window.postMessage.
 */
(function () {
  'use strict';

  // ── Helpers ──────────────────────────────────────────────────────────────
  function isJoinUrl(url) {
    if (!url) return false;
    return (
      url.includes('gamejoin.roblox.com') ||
      url.includes('/v1/games/join') ||
      url.includes('gameInstanceId')
    );
  }

  function tryExtractJobId(obj) {
    if (!obj || typeof obj !== 'object') return null;
    if (obj.jobId) return obj.jobId;
    if (obj.gameInstanceId) return obj.gameInstanceId;
    // Dig one level
    for (const key of Object.keys(obj)) {
      if (obj[key] && typeof obj[key] === 'object') {
        if (obj[key].jobId) return obj[key].jobId;
      }
    }
    return null;
  }

  function broadcast(jobId) {
    window.postMessage({ __rsc: true, type: 'RSC_JOB_ID', jobId }, '*');
  }

  // ── Patch fetch ───────────────────────────────────────────────────────────
  const _fetch = window.fetch;
  window.fetch = async function (...args) {
    const response = await _fetch.apply(this, args);
    const url = typeof args[0] === 'string' ? args[0] : args[0]?.url ?? '';
    if (isJoinUrl(url)) {
      try {
        const clone = response.clone();
        const data = await clone.json();
        const jobId = tryExtractJobId(data);
        if (jobId) broadcast(jobId);
      } catch (_) { /* non-JSON or clone error — ignore */ }
    }
    return response;
  };

  // ── Patch XMLHttpRequest ──────────────────────────────────────────────────
  const _open = XMLHttpRequest.prototype.open;
  const _send = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__rscUrl = url;
    return _open.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    if (isJoinUrl(this.__rscUrl)) {
      this.addEventListener('load', function () {
        try {
          const data = JSON.parse(this.responseText);
          const jobId = tryExtractJobId(data);
          if (jobId) broadcast(jobId);
        } catch (_) { /* ignore */ }
      });
    }
    return _send.apply(this, args);
  };

  // ── Check URL on page load (user may have joined via direct link) ─────────
  const params = new URLSearchParams(window.location.search);
  const urlJobId = params.get('gameInstanceId');
  if (urlJobId) broadcast(urlJobId);

  // ── Watch for URL changes (SPA navigation) ───────────────────────────────
  const _pushState = history.pushState;
  history.pushState = function (...args) {
    _pushState.apply(this, args);
    const p = new URLSearchParams(args[2]?.split?.('?')[1] ?? '');
    const id = p.get('gameInstanceId');
    if (id) broadcast(id);
  };

  console.log('[RSC] Interceptor active');
})();
