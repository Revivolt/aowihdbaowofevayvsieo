# Roblox Server Chat — Bio Edition

**No server. No Firebase. No account.** 
Communication happens entirely through Roblox profile bios — zero infrastructure needed.

---

## How it works

```
You type "hello"
  → Your bio is temporarily set to: {"rsc":1,"s":"a3f9bc12","t":1712345678,"m":"hello"}
  → Other players' extensions see your bio changed
  → They extract the message and show it in their chat window
  → After 45 seconds your original bio is automatically restored
```

Each message travels through your Roblox profile bio. Only people running this
extension and on the same server will see it. Your bio is restored after 45 seconds
— or when you close the tab.

---

## Files

```
roblox-bio-chat/
├── manifest.json    Chrome extension config
├── background.js    Opens the popup window (minimal)
├── content.js       Roblox API calls, bio polling, server discovery
├── interceptor.js   Captures the Roblox server/job ID at join time
├── chat.html        The popup window layout
├── chat.js          Popup window UI logic
└── chat.css         Popup window styles
```

---

## Install

1. Go to `chrome://extensions`
2. Enable **Developer mode** (top-right)
3. Click **Load unpacked** → select the `roblox-bio-chat/` folder
4. Done

---

## Usage

1. Open any Roblox game page (`roblox.com/games/…`)
2. Click **Play** — the chat window opens automatically
3. Wait a moment for the server to resolve (~3 s)
4. Type and send messages

The window is a **real separate OS window** (not a DOM overlay), so it sits above
the Roblox app in your taskbar like any other window.

### Keeping it on top of Roblox

Chrome doesn't expose an "always on top" API for extensions. Use your OS instead:

| OS | Method |
|---|---|
| **Windows 10/11** | Install [Microsoft PowerToys](https://aka.ms/installpowertoys) → press `Win + Ctrl + T` with the chat window focused |
| **Windows (manual)** | Right-click taskbar → "Always on top" if your taskbar version supports it |
| **macOS** | [Afloat](https://github.com/rwmanos/afloat) or [Window Focus](https://apps.apple.com/app/window-focus/id597543069) |
| **Linux** | Right-click title bar → "Always on Top" (most DEs support this natively) |

---

## Internals

### Communication architecture

```
[Roblox Tab]                         [Chat Popup Window]
 content.js                            chat.js
    |                                     |
    | writes rsc_server  ─────────────────┤ reads via storage.onChanged
    | writes rsc_messages ────────────────┤ renders new messages
    |                                     |
    |                     rsc_outgoing ───┤ writes { text, nonce }
    | reads rsc_outgoing ─┘               |
    | → calls Roblox bio API              |
```

All communication goes through `chrome.storage.session` — no service worker
needs to stay alive, no message passing between contexts.

### Bio format

```json
{"rsc":1,"s":"a3f9bc12","t":1712345678901,"m":"the message text"}
```

- `rsc`: version marker (always `1`)
- `s`: first 8 characters of the Roblox job/server ID
- `t`: Unix timestamp in milliseconds (used to deduplicate)
- `m`: the message text (max 200 chars)

### Player discovery

1. Extract `placeId` from the current page URL
2. Resolve `universeId` via `games.roblox.com/v1/games/multiget-place-details`
3. Paginate `games.roblox.com/v1/games/{universeId}/servers/Public` to find the current server by job ID
4. Extract player list; resolve any `id: 0` entries via username lookup
5. Poll each player's `users.roblox.com/v1/users/{id}` description every 3 seconds

---

## Limitations

- **Rate limits**: Roblox may throttle requests if polling many players simultaneously. Works best in servers with < 20 players.
- **Bio overwrite**: While the extension is active, your bio is temporarily replaced during sends. It's restored after 45 s.
- **Send cooldown**: Each message has a ~1.5 s cooldown to give the bio update time to propagate.
- **Always on top**: Requires an OS-level tool (see above).
