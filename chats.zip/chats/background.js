/**
 * background.js — Roblox Server Chat service worker
 *
 * Woken by chrome.runtime.sendMessage from content.js (the guaranteed way
 * to wake a sleeping MV3 service worker from a content script).
 *
 * Also handles the extension icon click.
 * Uses chrome.storage.local for the window ID (not session).
 */

console.log('[RSC BG] Service worker started');

// ── Message handler ───────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  console.log('[RSC BG] Message received:', msg.type);
  if (msg.type === 'OPEN_WINDOW') {
    openOrFocusWindow()
      .then(() => sendResponse({ ok: true }))
      .catch(e => {
        console.error('[RSC BG] openOrFocusWindow failed:', e.message);
        sendResponse({ ok: false, error: e.message });
      });
    return true; // keep channel open for async response
  }
});

// ── Icon click ────────────────────────────────────────────────────────────
chrome.action.onClicked.addListener(() => {
  console.log('[RSC BG] Icon clicked');
  openOrFocusWindow().catch(console.error);
});

// ── Track window close ────────────────────────────────────────────────────
chrome.windows.onRemoved.addListener((closedId) => {
  chrome.storage.local.get('rsc_window_id', ({ rsc_window_id: wid }) => {
    if (wid === closedId) {
      chrome.storage.local.remove('rsc_window_id');
      console.log('[RSC BG] Chat window closed, cleared ID');
    }
  });
});

// ── Window open/focus ─────────────────────────────────────────────────────
async function openOrFocusWindow() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get('rsc_window_id', async ({ rsc_window_id: wid }) => {
      if (wid) {
        try {
          await chrome.windows.update(wid, { focused: true });
          console.log('[RSC BG] Focused existing window', wid);
          resolve();
          return;
        } catch {
          chrome.storage.local.remove('rsc_window_id');
        }
      }

      try {
        const win = await chrome.windows.create({
          url:     chrome.runtime.getURL('chat.html'),
          type:    'popup',
          width:   340,
          height:  540,
          focused: true,
        });
        chrome.storage.local.set({ rsc_window_id: win.id });
        console.log('[RSC BG] Opened new window', win.id);
        resolve();
      } catch (e) {
        console.error('[RSC BG] Failed to create window:', e);
        reject(e);
      }
    });
  });
}
